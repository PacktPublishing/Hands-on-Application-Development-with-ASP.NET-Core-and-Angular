using FoodPos.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FoodPos.Controllers
{
    [Route("api/[controller]")]
    public class OrdersController : Controller
    {
        private readonly MyDbContext context;

        public OrdersController(MyDbContext context)
        {
            this.context = context;
        }

        [HttpGet]
        public IActionResult GetOrders()
        {
            var result = context.Orders
                            .Include(orders => orders.OrderItems)
                                .ThenInclude(a => a.Product)
                            .ToListAsync();
            return Ok(result);
        }

        [HttpPost]
        public IActionResult SaveOrder([FromBody] Order order)
        {
            context.Orders.Add(order);
            var result = context.SaveChanges();

            return Accepted(result);
        }
    }
}